<template>
	
	<modal-layouts name="editRecord" id="editRecord">
		
		<template slot="heading">Edit Record</template>

		<template slot="main">

			<div class="form-group">
				<label for="name">Name</label>

				<input type="text" 
					   name="name" 
					   id="name" 
					   class="form-control" 
					   v-model="editRec.name"
					   @keydown="delete errors.name">

				<span v-if="errors.name" class="text-danger">
					<small v-text="errors.name[0]"></small>
				</span>
			</div>

			

			<div class="form-group">
				<label for="phone">Phone</label>

				<input type="text" 
					   name="phone" 
					   id="phone" 
					   class="form-control" 
					   v-model="editRec.phone"
					   @keydown="delete errors.phone">

				<span v-if="errors.phone" class="text-danger">
					<small v-text="errors.phone[0]"></small>
				</span>
			</div>


			<div class="form-group">
				<label for="company">Company</label>

				<input type="text" 
					   name="company" 
					   id="company" 
					   class="form-control" 
					   v-model="editRec.company"
					   @keydown="delete errors.company">

				<span v-if="errors.company" class="text-danger">
					<small v-text="errors.company[0]"></small>
				</span>
			</div>

			<div class="form-group">
				<label for="address">Address</label>

				<textarea
					   name="address" 
					   id="address" 
					   class="form-control" 
					   v-model="editRec.address"
					   @keydown="delete errors.address"></textarea>

				<span v-if="errors.address" class="text-danger">
					<small v-text="errors.address[0]"></small>
				</span>
			</div>

		</template>

		<template slot="footer">
			<button type="button" 
					class="btn btn-outline-secondary" 
					@click="clearModal" 
					data-dismiss="modal">Close</button>

			<button type="submit" 
					class="btn btn-outline-primary" 
					@click="updateRecord">Save Changes</button>
		</template>

	</modal-layouts>

</template>

<script>
	import ModalLayouts from '../partials/ModalLayouts'

	export default {
		props: ['editRec'],

		data() {
			return {
				errors: [],
			}
		},

		components: { ModalLayouts },

		methods: {
			updateRecord() {
				axios.put(`/phonebooks/${this.editRec.id}`, this.editRec)
					.then(response => {
						this.$emit('recordUpdated', response);
						
						toast.fire({
						  type: 'success',
						  title: 'Record has been updated successfully!'
						})

						$('#editRecord').modal('hide');
					})
					.catch(error => this.errors = error.response.data.errors)
			},

			clearModal() {
				this.errors = [];
			}
		}
	};
</script>